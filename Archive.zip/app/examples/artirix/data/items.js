[{
	"id": "1171026",
	"image_src": "",
	"upgrades": ["Featured Home"],
	"address": "Paseo Mirasol, Tiburon, 94920, CA, United States",
	"type": "For sale",
	"mls": "21005314",
	"price": "$1,599,000",
	"created_at": "August 17",
	"expires_at": "November 17"
},{
	"id": "1171027",
	"image_src": "",
	"upgrades": ["Featured Home", "Featured Result"],
	"address": "W Dry Creek Rd, Healdsburg, 95448, CA, United States",
	"type": "For sale",
	"mls": "21008941",
	"price": "$899,000",
	"created_at": "August 17",
	"expires_at": "November 17"
},{
	"id": "1171028",
	"image_src": "",
	"upgrades": [],
	"address": "Mariner Green Ct, Corte Madera, 94925, CA, United States",
	"type": "For sale",
	"mls": "21024848",
	"price": "$495,000",
	"created_at": "August 17",
	"expires_at": "November 17"
}]