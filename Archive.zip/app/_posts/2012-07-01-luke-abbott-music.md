---
title:  "Luke Abbott"
categories: work
start: 2012-07-01
role: Site design &amp; development
tech:
 - HTML5
 - CSS
---
Luke Abbott is an electronic musician, and he wanted to revamp his personal site (it also functions as his main online presence).

I <a href="http://snd.rs/examples/lukeabbottmusic.co.uk">redesigned it</a> as an evolution of his then-current blog, trying to retain its intimacy and personality.