---
title:  "Sea Sentinel"
categories: music work
start: 2013-03-26
role: Director &amp; programmer
tech:
 - iPhone
 - VDMX
---
To publicise the release of Transept's second album, *Buff as Fuck*, I made <a href="https://vimeo.com/52951623" class="lightbox">a video</a> for the track *Sea Sentinel*.

It uses footage I shot while kayaking off the coast of Vancouver Island, Canada.
