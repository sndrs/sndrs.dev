---
title:  "Piccadilly Records"
categories: work
start: 2013-06-01
end: 2013-10-01
role: Site development
external_url: http://piccadillyrecords.com
tech:
 - Less
 - HTML5
 - PHP
---
[Pin Studio](http://pin-stud.io) contracted me to build a responsive and mobile-friendly new UI for the Piccadilly Records online shop, based on their mockups.