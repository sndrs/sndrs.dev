---
title:  "TheStreet.com, UK"
categories: work
start: 1999-10-01
end: 2000-08-01
role: Lead interaction designer &amp; front-end developer
tech: 
 - DHTML
 - CSS
 - Photoshop
---

I was invited to join many of my former FT.com colleagues (see below) to launch TheStreet.co.uk, the UK sister of TheStreet.com. 

I took overall responsibility for UI/UX and client-side code, and led a complete redesign and build, which took revenues beyond the forecasts.

I also designed a series of twenty adverts for display on the London Underground and across the web.