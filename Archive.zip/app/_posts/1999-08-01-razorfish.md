---
title:  "Razorfish UK"
categories: work
start: 1999-07-01
end: 1999-08-01
role: Front-end developer
tech: 
 - DHTML
 - CSS
---

I remade Flash presentations in DHMTL for National Westminster Bank, and coded the front end for the BAE Systems graduate recruitment site and Sharepeople.com.